for X in range (20,52, +2):
    print (X) 
    import time
    time.sleep(1)