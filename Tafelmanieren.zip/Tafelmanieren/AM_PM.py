for x in range (00,12, +1,):
    print (x, 'AM')
    import time
    time.sleep(1)
for B in range (13,24, +1,):
    print (B, 'PM')
    import time
    time.sleep(1)