Getal = input ("Getal?")

Getal = int(Getal)
for X in range (0,10):
    print (X  * Getal) 