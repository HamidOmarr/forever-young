for x in range (30,0, -1):
    print (x)
    import time
    time.sleep(1)

print("""
            ___
      |     | |
     / \    | |
    |o-o|===|-|
    |-o-|   | |
   /     \  | |
  | U     | | |
  | S     |=| |
  | A     | | |
  |_______| |_|
   |@| |@|  | |
 ___________|_|_
""")